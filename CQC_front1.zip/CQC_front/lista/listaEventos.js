const minhaLista = [];

module.exports = minhaLista;