const listaConexao = [];

module.exports = listaConexao;